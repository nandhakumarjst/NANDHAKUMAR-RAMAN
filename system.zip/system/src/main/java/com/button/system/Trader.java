package com.button.system;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;

public class Trader {
    private String party ;
    private String trader;
    private String company;
    private int price;

    private Date date;

    public Trader(String party, String trader, String company, int price, Date date) {
        this.party = party;
        this.trader = trader;
        this.company = company;
        this.price = price;
        this.date = date;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public String getTrader() {
        return trader;
    }

    public void setTrader(String trader) {
        this.trader = trader;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
