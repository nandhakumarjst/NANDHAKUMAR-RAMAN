package com.button.system;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

@RestController
public class MasterController {
    @GetMapping("seller")
    public List<Trader> getSeller() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        List<Trader> list = new ArrayList();
        try {
            Trader b1 = new Trader("Party A", "SELL", "IBM", 110,formatter.parse("2020-07-15"));
        Trader b2 = new Trader("Party A", "SELL", "INFY", 600,formatter.parse("2020-07-16"));
        Trader b3 = new Trader("Party A", "SELL", "GOOG", 500,formatter.parse("2020-07-17"));
        list.add(b1);
        list.add(b2);
        list.add(b3);
            return list;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return list;
    }
    @GetMapping("buyer")
    public List<Trader> getBuyer() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        List<Trader> list = new ArrayList();
        try {
            Trader b4 = new Trader("Party B", "BUY", "IBM", 110,formatter.parse("2020-07-15"));
        Trader b5 = new Trader("Party C", "BUY", "IBM", 110,formatter.parse("2020-07-15"));
        Trader b6 = new Trader("Party C", "BUY", "INFY", 600,formatter.parse("2020-07-16"));
        list.add(b4);
        list.add(b5);
        list.add(b6);
        return list;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return list;
    }
    @PostMapping("match")
    public List<Traders> getMatch(@RequestBody TraderDto traderDto, BindingResult bindingResult, HttpServletRequest request) {
        List<Traders> list = new ArrayList();
        List<Trader> seller = getSeller();
        List<Trader> buyer = getBuyer();
        for (Trader seller1 : seller) {
            for (Trader buyer1 : buyer) {
                if (seller1.getPrice() == buyer1.getPrice() && seller1.getCompany().equals(buyer1.getCompany())) {
                    if((seller1.getParty().equals(traderDto.getParties()) || buyer1.getParty().equals(traderDto.getParties()))&&traderDto.getSymbol()==null && !traderDto.getSymbol().equals("")) {
                        if (seller1.getCompany().equals(traderDto.getSymbol()) ) {
                            Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
                            list.add(b3);
                        }
                    }else
if(traderDto.getParties()==null && !traderDto.getParties().equals("")) {
    if (seller1.getParty().equals(traderDto.getParties()) || buyer1.getParty().equals(traderDto.getParties())) {
        Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
        list.add(b3);
    }
}else if(traderDto.getSymbol()==null && !traderDto.getSymbol().equals("")) {
                        if (seller1.getCompany().equals(traderDto.getSymbol()) ) {
                            Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
                            list.add(b3);
                        }
                    }else if(traderDto.getDate()==null && !traderDto.getDate().equals("")) {
    if (seller1.getDate().equals(traderDto.getDate()) ) {
        Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
        list.add(b3);
    }
}else {
    Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
    list.add(b3);
}





                }
            }
        }
        return list;
    }

    @PostMapping("notMatch")
    public List<Traders> getnotMatch(@RequestBody TraderDto traderDto, BindingResult bindingResult, HttpServletRequest request) {
        List<Traders> list = new ArrayList();
        List<Trader> seller = getSeller();
        List<Trader> buyer = getBuyer();
        for (Trader seller1 : seller) {
            for (Trader buyer1 : buyer) {
                if (seller1.getPrice() != buyer1.getPrice() && !seller1.getCompany().equals(buyer1.getCompany())) {
                    if((seller1.getParty().equals(traderDto.getParties()) || buyer1.getParty().equals(traderDto.getParties()))&&traderDto.getSymbol()==null && !traderDto.getSymbol().equals("")) {
                        if (seller1.getCompany().equals(traderDto.getSymbol()) ) {
                            Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
                            list.add(b3);
                        }
                    }else
                    if(traderDto.getParties()==null && !traderDto.getParties().equals("")) {
                        if (seller1.getParty().equals(traderDto.getParties()) || buyer1.getParty().equals(traderDto.getParties())) {
                            Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
                            list.add(b3);
                        }
                    }else if(traderDto.getSymbol()==null && !traderDto.getSymbol().equals("")) {
                        if (seller1.getCompany().equals(traderDto.getSymbol()) ) {
                            Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
                            list.add(b3);
                        }
                    }else if(traderDto.getDate()==null && !traderDto.getDate().equals("")) {
                        if (seller1.getDate().equals(traderDto.getDate()) ) {
                            Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
                            list.add(b3);
                        }
                    }
                    else if(traderDto.getPrice()==null && !traderDto.getPrice().equals("")) {
                        if (seller1.getDate().equals(traderDto.getDate()) ) {
                            Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
                            list.add(b3);
                        }
                    }
                    else {
                        Traders b3 = new Traders("Seller = " + seller1.getParty(), " Buyer = " + buyer1.getParty(), " Stock =" + buyer1.getCompany(), buyer1.getPrice(), buyer1.getDate());
                        list.add(b3);
                    }





                }
            }
        }
        return list;
    }

}