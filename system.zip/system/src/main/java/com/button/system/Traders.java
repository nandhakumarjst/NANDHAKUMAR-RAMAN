package com.button.system;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;

public class Traders {
    private String seller ;
    private String buyer ;
    private String stock ;
    private int price ;

    private Date date;

    public Traders(String seller, String buyer, String stock, int price, Date date) {
        this.seller = seller;
        this.buyer = buyer;
        this.stock = stock;
        this.price = price;
        this.date = date;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
